<!DOCTYPE html>
<html>
<head>
 <title>Laravel 8 Send Email Example</title>

 <style>
    .ntt_shop {
      width: 100%;
      padding: 20px;
      box-sizing: border-box;
      margin: 0;
    }
    .ntt__shop_order-header {
      width: 100%;
      padding: 30px 0;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .ntt__shop_order-header > div {
      text-align: center;
    }
    .ntt__shop_order--header-img {
      width: 200px;
    }
    .ntt__shop_order-header span {
      font-size: 1.5rem;
      color: #fff;
      font-weight: 600;
      margin: 0 auto;
      display: inline-block;
    }

    .ntt__shop_order--content-title {
      font-size: 1.2rem;
      color: #333;
      font-weight: 600;
      text-align: center;
    }
    .ntt__shop_order--content-text {
      text-align: center;
    }

    .ntt__shop_order-infor {
      display: flex;
      margin-bottom: 30px;
    }
    .ntt__shop_order--infor-left,
    .ntt__shop_order--infor-right {
      flex: 1;
    }
    .ntt__shop_order--infor-left {
      margin-right: 12px;
    }
    .ntt__shop_order--infor-right {
      margin-left: 12px;
    }
    .ntt__shop_order-infor-title {
      text-align: center;
      font-size: 1.1rem;
    }
    .ntt__shop-line {
      height: 1px;
      background: #333;
    }
    .ntt__shop_orderdetails {
      display: flex;
    }
    .ntt__shop-table,
    .ntt__shop-table th,
    .ntt__shop-table td {
      border: 1px solid black;
      border-collapse: collapse;
    }
    .ntt__shop_order-button {
      text-align: center;
    }

    .ntt__shop_order-link {
      display: inline-block;
      text-decoration: none;
      text-transform: uppercase;
      font-size: 1.2rem;
      background: #111111;
      color: white;
      padding: 0.5rem 1.2rem;
    }
    .ntt__shop_order-note {
      margin-top: 30px;
    }
    .ntt__shop_order-address {
      margin-top: 10px;
    }
    </style>

</head>

<body>
    <div class="ntt_shop">
        <div class="ntt__shop_order-header">
          <div>
            <img
              class="ntt__shop_order--header-img"
              src="https://th.bing.com/th/id/OIP.GBvfuOZVtnz_NFcYtqeGdAHaEf?w=309&h=187&c=7&r=0&o=5&dpr=1.1&pid=1.7"
            />
            <h1 class="ntt__shop_order--header-name">NTT SHOP</h1>
          </div>
        </div>
        <div class="ntt__shop_order-content">
          <h2 class="ntt__shop_order--content-title">
            Xin chào {{$details["user_fullname"]}}!
          </h2>
          <p class="ntt__shop_order--content-text">
            Cảm ơn Anh/Chị đã đặt hàng tại <strong>NTT Shop</strong>!
          </p>
          <p class="ntt__shop_order--content-text">
            Đơn hàng của Anh/Chị đã được tiếp nhận. Chúng tôi sẽ nhanh chóng liên
            hệ với Anh/Chị.
          </p>
        </div>
        <div class="ntt__shop-line" />
        <div class="ntt__shop_order-infor">
          <div class="ntt__shop_order--infor-left">
            <h2 class="ntt__shop_order-infor-title">Thông tin mua hàng</h2>
            <div class="ntt__shop_order--infor-content">
              <span>Họ tên người nhận hàng: </span>
              <strong>{{$details["user_recivername"]}}</strong>
            </div>
            <div class="ntt__shop_order--infor-content">
              <span>SĐT: </span>
              <strong>{{$details["user_reciverphone"]}}</strong>
            </div>
            <div class="ntt__shop_order--infor-content">
              <span>Email: </span>
              <strong>{{$details["user_email"]}}</strong>
            </div>
          </div>
          <div class="ntt__shop_order--infor-right">
            <h2 class="ntt__shop_order-infor-title">Địa chỉ nhận hàng</h2>
            <div class="ntt__shop_order--infor-content">
              <p>{{$details["user_reciveraddress"]}}</p>
            </div>
          </div>
        </div>
        <div class="ntt__shop_order-infor">
          <div class="ntt__shop_order--infor-left">
            <h2 class="ntt__shop_order-infor-title">Phương thức thanh toán</h2>
            <div class="ntt__shop_order--infor-content">
              <p>{{$details["user_methodepayment"]}}</p>
            </div>
          </div>
          <div class="ntt__shop_order--infor-right">
            <h2 class="ntt__shop_order-infor-title">Phương thức vận chuyển</h2>
            <div class="ntt__shop_order--infor-content">
              <p>gojeck</p>
            </div>
          </div>
        </div>
        <div class="ntt__shop-line" />
        <div>
          <h2 class="ntt__shop_order-infor-title">Chi tiết đơn hàng</h2>
          <div class="ntt__shop_order-infor">
            <div class="ntt__shop_order--infor-left">
              <div class="ntt__shop_order--infor-content">
                <span>Mã đơn hàng: </span>
                <strong>#{{$details["order_id"]}}</strong>
              </div>
            </div>
            <div class="ntt__shop_order--infor-right">
              <div class="ntt__shop_order--infor-content">
                <span>Ngày đặt: </span>
                <strong>{{date_format($details["created_at"],"Y/m/d H:i:s")}}</strong>
              </div>
            </div>
          </div>
          <div class="ntt__shop_order-button">
            <a href="" class="ntt__shop_order-link">
              Kiểm tra đơn hàng
            </a>
          </div>
  
          <div class="ntt__shop_order-note">
            <strong>Ghi chú: </strong>
            <span>{{$details["note"]}}!</span
            >
          </div>
          <div class="ntt__shop_order-address">
            Nếu anh/chị có bất kỳ thắc mắc nào có thể liên hệ với chúng tôi tại
            mail:
            <a href="mailto:ntt.shop.sneakers@gmail.com">
              ntt.shop.3006@gmail.com
            </a>
            hoặc
            <a href="tel:0383608951">0383608951</a>
          </div>
        </div>
      </div>
</body>
</html>
